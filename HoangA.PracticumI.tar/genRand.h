//genRand.h
#ifndef GENRAND_H
#define GENRAND_H

int genRand(int min, int max);

#endif // GENRAND_H